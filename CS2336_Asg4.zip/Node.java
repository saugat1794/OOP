package CS2336_Asg4_SXG200088;

//Node class:
public class Node {
	String data;
	Node next;
	int numberofWord = 1;
	String line = "";
	
	// constructor:
	public Node(String data, String line)
	{
		//numberofWord = 1;
		this.data = data;
		this.line = line;
		this.next = null;
	}
	
}
