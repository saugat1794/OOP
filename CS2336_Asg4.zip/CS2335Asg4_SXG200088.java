/* This program takes file from the user and sort the words in
 * alphabetical order.
 * Also this program tracks the number of word in the text file, 
 * and also keeps track of the line number present in the file.
 * 
 * After completion of sorting. 
 * Displaying total number of word present in the file.
 * Displaying Total number of lines and unique word present in the file.
 * 
*
* Written by Saugat Gyawali for CS2336.001, assignment 4, starting October 14, 2021.
NetID: SXG200088
*/

// Main class file:

package CS2336_Asg4_SXG200088;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class CS2335Asg4_SXG200088 {
	
	public static void main(String[] args) throws FileNotFoundException {

		boolean toContinue = true;
		LinkedList list = new LinkedList();			// linked list created.
		Scanner input = new Scanner(System.in);
		
		do
		{
			
			System.out.print("Enter a filename: ");
			String filename = input.nextLine();
			
			// need to stop asking if asterisk is entered.
			if(filename.equals("*"))
			{
			System.out.println("THANK YOU!");
			break;
			}
			
			
			File file = new File(filename);
			int lineNumber = 0;
			 int wordCount=0;
			 
			 // checking of file exists or not
			if(file.exists())
			{
				Scanner inputFile = new Scanner(file);
				
				// takes all words from the file till last.
				while(inputFile.hasNextLine())
				{
					lineNumber++;
					String line = inputFile.nextLine();
					
					if(line.isBlank())
					{
						continue;
					}
					
					// stores each and every word excluding the punctuation.
					String[] word = line.split("[-? , . ! : ; \" ( )]");
					
					// for each loop to pass each and every word.
					for(String e: word)
					{
						// need to exclude a, an, the, and blank line to be passed.
						if(!(e.equalsIgnoreCase("a") || e.equalsIgnoreCase("an") || e.equalsIgnoreCase("the") || e.isBlank() == true))
						{
							wordCount++;
							list.insert(e, lineNumber);
						}
					}
				}
				
				// displaying the contents.
				list.display(lineNumber, wordCount);
				
				// pointing node again into head.
				list.clear();
				inputFile.close();
			}
			
			// If file is not found.
			else
			{
				System.out.println("File not Found. Try it again with another file.");
			}
			
		}while(toContinue);
		
				
	}
}
