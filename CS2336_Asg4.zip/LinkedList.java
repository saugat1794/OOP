package CS2336_Asg4_SXG200088;

//Linked list class and different implementation to sort words.
public class LinkedList
{
	static int count = 0;
	Node head = null;
	Node current = null;
	Node previous = null;
	
	// insertion of node.
	public void insert(String inputData, int lineNumber)
	{	
		current = head;
		previous = null;
		
		// it is for first node. After inserting need to terminate function.
		if(head == null)
		{
			Node node = new Node(inputData, String.valueOf(lineNumber));
			current = node;
			head = node;
			return;
		}
		
		// Need to check till last of the list.
		while(current.next != null)
		{
			 
			if(current.data.compareToIgnoreCase(inputData) < 0)
			{
				// keeping track of list.
				previous = current;
				current = current.next;
			}
			// if encountered any greater number or equal, no need to check further.
			else
				break;
		}
		
		
		/*Current.next is null when the node is either in 
		 * first or at last.
		 * Need to work for first and last node.
		 */
		// if the list is moved till last or is in head. Enters this part:
		if(current.next == null)
		{
			// creation of new node to be inserted.
			Node node = new Node(inputData, String.valueOf(lineNumber));
			
			// when needed to be work with first node.
			if(previous == null)
			{
				// if inserted after first node.
				if(current.data.compareToIgnoreCase(inputData) > 0)
					{
						head = node;
						head.next = current;
						//previous = head;
					}
				// if inserted before the first node.
				else if(current.data.compareToIgnoreCase(inputData) < 0)
					{
						current.next = node;
					}
			}
			// when needed to be placed in just before last node.
			else if(previous.next == current && current.data.compareToIgnoreCase(inputData) > 0)
			{
				previous.next = node;
				node.next = current;
			}
			
			// when needed to be placed after last.
			else if(current.data.compareToIgnoreCase(inputData) < 0)
			{
				current.next = node;
				node.next = null;
			}
			
		}
		
		// if need to be inserted in between. or contains already nodes.
		else if(current.data.compareToIgnoreCase(inputData) > 0)
		{
			Node node = new Node(inputData, String.valueOf(lineNumber));
			
			// if need to be inserted before first node.
			if(previous == null)
			{
				head = node;
				head.next = current;
			}
			
			// if need to be inserted in between.
			else
			{
				previous.next = node;
				node.next = current;	
			}
			
		}
		
		// if the words are equal we need to keep track of it. 
		 if(current.data.compareToIgnoreCase(inputData) == 0)
		{	
			// increase the word which is repeated.
			count++;
			
			// increase the number of word present in the text file.
			current.numberofWord++;	
			
			// need to take care whether it is present in same line or not.
			if(!current.line.contains(String.valueOf(lineNumber)))
			{
				current.line += "," + String.valueOf(lineNumber);
			}	
		}	 
	}
	
	// this function points to the head for another file after calling of each time when file is called.
	public void clear()
	{
		head = null;
	}
	
	// Display function to display required result.
	public void display(int lineNumber, int wordCount)
	{
			current = head;
			
			// need to print the content of list.
			System.out.printf("%-15s%-15s%-150s\n","WORD", "No of Word", "Line Number");
			System.out.println("______________________________________________________");

			while(current != null)
			{	
				System.out.printf("%-15s%-15d%-150s\n",current.data, current.numberofWord, current.line);
				current = current.next;
			}
			System.out.println("####################################################################");
			System.out.println(" 			TEXT FILE INFORMATION								");
			System.out.println("####################################################################");
			System.out.println("Total number of words: " + wordCount);
			// for unique word I subtracted total word count with duplicate word.
			System.out.println("Total Number of unique words: " + (wordCount - count));
			System.out.println("Total number of lines: " + lineNumber);
			System.out.println("####################################################################");

			System.out.println();
			//again changing count variable into 0 for next file reading.
			count = 0;
	}
	
}